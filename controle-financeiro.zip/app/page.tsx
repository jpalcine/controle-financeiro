"use client";

import { useEffect, useMemo, useState } from "react";

type StatusType = "pago" | "pendente";

type Transaction = {
  id: string;
  date: string;
  description: string;
  category: string;
  amount: number;
  paymentMethod: string;
  status: StatusType;
};

type InstallmentPurchase = {
  id: string;
  description: string;
  category: string;
  totalAmount: number;
  totalInstallments: number;
  installmentAmount: number;
  startMonth: string;
  notes?: string;
};

type SalaryByMonth = Record<string, number>;

const categorias = [
  "Casa",
  "Alimentação",
  "Transporte",
  "Saúde",
  "Lazer",
  "Contas",
  "Cartão",
  "Outros",
];

const formasPagamento = [
  "Pix",
  "Dinheiro",
  "Cartão de débito",
  "Cartão de crédito",
  "Boleto",
];

function getCurrentMonth() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}

function formatCurrency(value: number) {
  return value.toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  });
}

function formatMonthLabel(month: string) {
  const [year, monthNumber] = month.split("-").map(Number);
  const date = new Date(year, (monthNumber || 1) - 1, 1);
  return date.toLocaleDateString("pt-BR", {
    month: "long",
    year: "numeric",
  });
}

function getMonthOptions(selectedMonth: string) {
  const [year, month] = selectedMonth.split("-").map(Number);
  const base = new Date(year, (month || 1) - 1, 1);
  const options: string[] = [];

  for (let offset = -12; offset <= 12; offset += 1) {
    const date = new Date(base.getFullYear(), base.getMonth() + offset, 1);
    const value = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
    options.push(value);
  }

  return options;
}

function getMonthsDiff(startMonth: string, targetMonth: string) {
  const [startYear, startMonthNumber] = startMonth.split("-").map(Number);
  const [targetYear, targetMonthNumber] = targetMonth.split("-").map(Number);
  return (targetYear - startYear) * 12 + (targetMonthNumber - startMonthNumber);
}

export default function Home() {
  const [selectedMonth, setSelectedMonth] = useState(getCurrentMonth());
  const [showTransactionForm, setShowTransactionForm] = useState(false);
  const [showInstallmentForm, setShowInstallmentForm] = useState(false);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [installments, setInstallments] = useState<InstallmentPurchase[]>([]);
  const [salaryByMonth, setSalaryByMonth] = useState<SalaryByMonth>({});

  const [date, setDate] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("Outros");
  const [amount, setAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("Pix");
  const [status, setStatus] = useState<StatusType>("pago");
  const [salaryInput, setSalaryInput] = useState("");

  const [installmentDescription, setInstallmentDescription] = useState("");
  const [installmentCategory, setInstallmentCategory] = useState("Cartão");
  const [installmentTotalAmount, setInstallmentTotalAmount] = useState("");
  const [installmentCount, setInstallmentCount] = useState("");
  const [installmentStartMonth, setInstallmentStartMonth] = useState(getCurrentMonth());
  const [installmentNotes, setInstallmentNotes] = useState("");

  useEffect(() => {
    const savedTransactions = localStorage.getItem("controle-financeiro-transactions");
    const savedInstallments = localStorage.getItem("controle-financeiro-installments");
    const savedSalaries = localStorage.getItem("controle-financeiro-salaries");

    if (savedTransactions) {
      try { setTransactions(JSON.parse(savedTransactions)); } catch { localStorage.removeItem("controle-financeiro-transactions"); }
    }
    if (savedInstallments) {
      try { setInstallments(JSON.parse(savedInstallments)); } catch { localStorage.removeItem("controle-financeiro-installments"); }
    }
    if (savedSalaries) {
      try { setSalaryByMonth(JSON.parse(savedSalaries)); } catch { localStorage.removeItem("controle-financeiro-salaries"); }
    }
  }, []);

  useEffect(() => { localStorage.setItem("controle-financeiro-transactions", JSON.stringify(transactions)); }, [transactions]);
  useEffect(() => { localStorage.setItem("controle-financeiro-installments", JSON.stringify(installments)); }, [installments]);
  useEffect(() => { localStorage.setItem("controle-financeiro-salaries", JSON.stringify(salaryByMonth)); }, [salaryByMonth]);
  useEffect(() => { const salary = salaryByMonth[selectedMonth]; setSalaryInput(salary ? String(salary) : ""); }, [selectedMonth, salaryByMonth]);

  const monthOptions = useMemo(() => getMonthOptions(selectedMonth), [selectedMonth]);
  const currentSalary = salaryByMonth[selectedMonth] || 0;

  const monthTransactions = useMemo(() => transactions.filter((item) => item.date.startsWith(selectedMonth)).sort((a, b) => b.date.localeCompare(a.date)), [selectedMonth, transactions]);
  const monthInstallments = useMemo(() => installments.map((item) => {
      const diff = getMonthsDiff(item.startMonth, selectedMonth);
      if (diff < 0 || diff >= item.totalInstallments) return null;
      return { ...item, currentInstallment: diff + 1 };
    }).filter((item): item is InstallmentPurchase & { currentInstallment: number } => Boolean(item)).sort((a, b) => a.description.localeCompare(b.description)), [installments, selectedMonth]);

  const totalTransactionsMonth = useMemo(() => monthTransactions.reduce((acc, item) => acc + item.amount, 0), [monthTransactions]);
  const totalPaid = useMemo(() => monthTransactions.filter((item) => item.status === "pago").reduce((acc, item) => acc + item.amount, 0), [monthTransactions]);
  const totalPending = useMemo(() => monthTransactions.filter((item) => item.status === "pendente").reduce((acc, item) => acc + item.amount, 0), [monthTransactions]);
  const totalInstallmentsMonth = useMemo(() => monthInstallments.reduce((acc, item) => acc + item.installmentAmount, 0), [monthInstallments]);

  const totalMonth = totalTransactionsMonth + totalInstallmentsMonth;
  const realBalance = currentSalary - totalPaid;
  const projectedBalance = currentSalary - totalPaid - totalPending - totalInstallmentsMonth;

  function resetTransactionForm() { setDate(""); setDescription(""); setCategory("Outros"); setAmount(""); setPaymentMethod("Pix"); setStatus("pago"); }
  function resetInstallmentForm() { setInstallmentDescription(""); setInstallmentCategory("Cartão"); setInstallmentTotalAmount(""); setInstallmentCount(""); setInstallmentStartMonth(selectedMonth); setInstallmentNotes(""); }
  function closeTransactionModal() { setShowTransactionForm(false); }
  function closeInstallmentModal() { setShowInstallmentForm(false); }

  function handleSubmitTransaction(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const parsedAmount = Number(amount.replace(",", "."));
    if (!date || !description.trim() || !parsedAmount || parsedAmount <= 0) { alert("Preencha data, descrição e valor corretamente."); return; }
    const newTransaction: Transaction = { id: crypto.randomUUID(), date, description: description.trim(), category, amount: parsedAmount, paymentMethod, status };
    setTransactions((prev) => [newTransaction, ...prev].sort((a, b) => b.date.localeCompare(a.date)));
    resetTransactionForm(); closeTransactionModal();
  }

  function handleSubmitInstallment(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const parsedTotalAmount = Number(installmentTotalAmount.replace(",", "."));
    const parsedInstallments = Number(installmentCount);
    if (!installmentDescription.trim() || !installmentStartMonth || !parsedTotalAmount || parsedTotalAmount <= 0 || !parsedInstallments || parsedInstallments <= 1) {
      alert("Preencha descrição, valor total, mês inicial e quantidade de parcelas corretamente."); return;
    }
    const installmentAmount = parsedTotalAmount / parsedInstallments;
    const newInstallment: InstallmentPurchase = { id: crypto.randomUUID(), description: installmentDescription.trim(), category: installmentCategory, totalAmount: parsedTotalAmount, totalInstallments: parsedInstallments, installmentAmount, startMonth: installmentStartMonth, notes: installmentNotes.trim() };
    setInstallments((prev) => [newInstallment, ...prev]);
    resetInstallmentForm(); closeInstallmentModal();
  }

  function handleDeleteTransaction(id: string) { if (window.confirm("Deseja excluir este lançamento?")) setTransactions((prev) => prev.filter((item) => item.id !== id)); }
  function handleDeleteInstallment(id: string) { if (window.confirm("Deseja excluir esta compra parcelada?")) setInstallments((prev) => prev.filter((item) => item.id !== id)); }

  function saveSalary() {
    const parsedSalary = Number(salaryInput.replace(",", "."));
    if (!salaryInput.trim()) { setSalaryByMonth((prev) => { const updated = { ...prev }; delete updated[selectedMonth]; return updated; }); return; }
    if (!parsedSalary || parsedSalary <= 0) { alert("Informe um salário válido para este mês."); return; }
    setSalaryByMonth((prev) => ({ ...prev, [selectedMonth]: parsedSalary }));
  }

  return (
    <main className="min-h-screen bg-slate-100 text-slate-900">
      <div className="mx-auto max-w-6xl px-4 py-6 md:px-6 md:py-8">
        <section className="mb-6 rounded-3xl bg-gradient-to-r from-slate-900 to-slate-700 p-6 text-white shadow-lg">
          <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <p className="text-sm text-slate-300">Seu painel financeiro</p>
              <h1 className="mt-1 text-3xl font-bold md:text-4xl">Controle Financeiro</h1>
              <p className="mt-2 text-sm text-slate-300">Organize seu mês, acompanhe o salário e veja o que ainda sobra.</p>
            </div>
            <div className="grid gap-3 sm:grid-cols-[minmax(180px,220px)_1fr]">
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-200">Mês de referência</label>
                <select value={selectedMonth} onChange={(e) => setSelectedMonth(e.target.value)} className="w-full rounded-2xl border border-white/20 bg-white/10 px-4 py-3 text-white outline-none backdrop-blur placeholder:text-slate-300">
                  {monthOptions.map((item) => <option key={item} value={item} className="text-slate-900">{formatMonthLabel(item)}</option>)}
                </select>
              </div>
              <div className="flex flex-wrap gap-3 sm:justify-end">
                <button onClick={() => { setDate(`${selectedMonth}-01`); setShowTransactionForm(true); }} className="rounded-2xl bg-white px-5 py-3 font-semibold text-slate-900 transition hover:scale-[1.02]">+ Adicionar gasto</button>
                <button onClick={() => { setInstallmentStartMonth(selectedMonth); setShowInstallmentForm(true); }} className="rounded-2xl bg-white/10 px-5 py-3 font-semibold text-white ring-1 ring-white/20 transition hover:bg-white/15">+ Adicionar parcelado</button>
              </div>
            </div>
          </div>
        </section>

        <section className="mb-6 rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <p className="text-sm text-slate-500">Salário do mês selecionado</p>
              <h2 className="mt-1 text-2xl font-bold capitalize text-slate-900">{formatMonthLabel(selectedMonth)}</h2>
            </div>
            <div className="flex w-full flex-col gap-3 sm:flex-row lg:max-w-xl">
              <input type="number" step="0.01" placeholder="Informe o salário do mês" value={salaryInput} onChange={(e) => setSalaryInput(e.target.value)} className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none transition focus:border-slate-900" />
              <button onClick={saveSalary} className="rounded-2xl bg-slate-900 px-5 py-3 font-semibold text-white transition hover:bg-slate-800">Salvar salário</button>
            </div>
          </div>
        </section>

        <section className="mb-6 grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-6">
          <Card label="Salário" value={formatCurrency(currentSalary)} color="text-sky-600" />
          <Card label="Gasto do mês" value={formatCurrency(totalMonth)} color="text-rose-500" />
          <Card label="Pago" value={formatCurrency(totalPaid)} color="text-emerald-600" />
          <Card label="Pendente" value={formatCurrency(totalPending)} color="text-amber-500" />
          <Card label="Parcelas do mês" value={formatCurrency(totalInstallmentsMonth)} color="text-violet-600" />
          <div className="rounded-3xl bg-slate-900 p-5 text-white shadow-sm ring-1 ring-slate-800">
            <p className="text-sm text-slate-300">Quanto sobrou</p>
            <h2 className="mt-3 text-3xl font-bold">{formatCurrency(projectedBalance)}</h2>
            <p className="mt-2 text-xs text-slate-300">Saldo real: {formatCurrency(realBalance)}</p>
          </div>
        </section>

        <section className="mb-6 grid gap-6 xl:grid-cols-[1.25fr_0.95fr]">
          <div className="rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
            <SectionHeader title="Lançamentos do mês" subtitle={`Gastos registrados manualmente em ${formatMonthLabel(selectedMonth)}`} onClick={() => { setDate(`${selectedMonth}-01`); setShowTransactionForm(true); }} />
            {monthTransactions.length === 0 ? <EmptyState text="Nenhum lançamento registrado neste mês" /> : (
              <div className="space-y-3">{monthTransactions.map((item) => (
                <div key={item.id} className="flex flex-col gap-4 rounded-2xl border border-slate-200 p-4 transition hover:bg-slate-50 md:flex-row md:items-center md:justify-between">
                  <div className="min-w-0"><p className="truncate text-base font-semibold text-slate-900">{item.description}</p><p className="mt-1 text-sm text-slate-500">{item.date} • {item.category} • {item.paymentMethod}</p></div>
                  <div className="flex flex-wrap items-center gap-3">
                    <span className={`rounded-full px-3 py-1 text-sm font-medium ${item.status === "pago" ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700"}`}>{item.status === "pago" ? "Pago" : "Pendente"}</span>
                    <p className="min-w-[120px] text-left text-base font-bold text-slate-900 md:text-right">{formatCurrency(item.amount)}</p>
                    <button onClick={() => handleDeleteTransaction(item.id)} className="rounded-xl bg-rose-50 px-3 py-2 text-sm font-medium text-rose-600 transition hover:bg-rose-100">Excluir</button>
                  </div>
                </div>
              ))}</div>
            )}
          </div>

          <div className="rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
            <SectionHeader title="Parcelas do cartão" subtitle={`Compras parceladas que caem em ${formatMonthLabel(selectedMonth)}`} onClick={() => { setInstallmentStartMonth(selectedMonth); setShowInstallmentForm(true); }} />
            {monthInstallments.length === 0 ? <EmptyState text="Nenhuma parcela ativa neste mês" /> : (
              <div className="space-y-3">{monthInstallments.map((item) => (
                <div key={item.id} className="rounded-2xl border border-slate-200 p-4 transition hover:bg-slate-50">
                  <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                    <div className="min-w-0"><p className="truncate text-base font-semibold text-slate-900">{item.description}</p><p className="mt-1 text-sm text-slate-500">{item.category} • início em {formatMonthLabel(item.startMonth)}</p><p className="mt-1 text-sm text-slate-500">Parcela {item.currentInstallment}/{item.totalInstallments}{item.notes ? ` • ${item.notes}` : ""}</p></div>
                    <div className="flex flex-wrap items-center gap-3">
                      <span className="rounded-full bg-violet-100 px-3 py-1 text-sm font-medium text-violet-700">{item.currentInstallment}/{item.totalInstallments}</span>
                      <p className="min-w-[120px] text-left text-base font-bold text-slate-900 md:text-right">{formatCurrency(item.installmentAmount)}</p>
                      <button onClick={() => handleDeleteInstallment(item.id)} className="rounded-xl bg-rose-50 px-3 py-2 text-sm font-medium text-rose-600 transition hover:bg-rose-100">Excluir</button>
                    </div>
                  </div>
                </div>
              ))}</div>
            )}
          </div>
        </section>
      </div>

      {showTransactionForm && <Modal title="Novo lançamento" subtitle="Preencha os dados do gasto do mês" onClose={closeTransactionModal}><form onSubmit={handleSubmitTransaction} className="grid grid-cols-1 gap-4 md:grid-cols-2"><Field label="Data"><input type="date" value={date} onChange={(e) => setDate(e.target.value)} className={inputClass} /></Field><Field label="Valor"><input type="number" step="0.01" placeholder="0,00" value={amount} onChange={(e) => setAmount(e.target.value)} className={inputClass} /></Field><Field label="Descrição" className="md:col-span-2"><input type="text" placeholder="Ex: Mercado, gasolina, internet..." value={description} onChange={(e) => setDescription(e.target.value)} className={inputClass} /></Field><Field label="Categoria"><select value={category} onChange={(e) => setCategory(e.target.value)} className={inputClass}>{categorias.map((item) => <option key={item} value={item}>{item}</option>)}</select></Field><Field label="Forma de pagamento"><select value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)} className={inputClass}>{formasPagamento.map((item) => <option key={item} value={item}>{item}</option>)}</select></Field><Field label="Status"><select value={status} onChange={(e) => setStatus(e.target.value as StatusType)} className={inputClass}><option value="pago">Pago</option><option value="pendente">Pendente</option></select></Field><div className="flex items-end gap-3 md:col-span-2"><button type="submit" className="rounded-2xl bg-slate-900 px-5 py-3 font-semibold text-white transition hover:bg-slate-800">Salvar gasto</button><button type="button" onClick={resetTransactionForm} className="rounded-2xl bg-slate-100 px-5 py-3 font-semibold text-slate-700 transition hover:bg-slate-200">Limpar</button></div></form></Modal>}
      {showInstallmentForm && <Modal title="Nova compra parcelada" subtitle="Cadastre uma vez e o sistema distribui as parcelas pelos meses." onClose={closeInstallmentModal}><form onSubmit={handleSubmitInstallment} className="grid grid-cols-1 gap-4 md:grid-cols-2"><Field label="Descrição" className="md:col-span-2"><input type="text" placeholder="Ex: Celular, geladeira, seguro..." value={installmentDescription} onChange={(e) => setInstallmentDescription(e.target.value)} className={inputClass} /></Field><Field label="Valor total"><input type="number" step="0.01" placeholder="0,00" value={installmentTotalAmount} onChange={(e) => setInstallmentTotalAmount(e.target.value)} className={inputClass} /></Field><Field label="Quantidade de parcelas"><input type="number" min="2" placeholder="Ex: 10" value={installmentCount} onChange={(e) => setInstallmentCount(e.target.value)} className={inputClass} /></Field><Field label="Mês da primeira parcela"><input type="month" value={installmentStartMonth} onChange={(e) => setInstallmentStartMonth(e.target.value)} className={inputClass} /></Field><Field label="Categoria"><select value={installmentCategory} onChange={(e) => setInstallmentCategory(e.target.value)} className={inputClass}>{categorias.map((item) => <option key={item} value={item}>{item}</option>)}</select></Field><Field label="Observação" className="md:col-span-2"><input type="text" placeholder="Opcional" value={installmentNotes} onChange={(e) => setInstallmentNotes(e.target.value)} className={inputClass} /></Field><div className="flex items-end gap-3 md:col-span-2"><button type="submit" className="rounded-2xl bg-slate-900 px-5 py-3 font-semibold text-white transition hover:bg-slate-800">Salvar parcelado</button><button type="button" onClick={resetInstallmentForm} className="rounded-2xl bg-slate-100 px-5 py-3 font-semibold text-slate-700 transition hover:bg-slate-200">Limpar</button></div></form></Modal>}
    </main>
  );
}

const inputClass = "w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none transition focus:border-slate-900";

function Card({ label, value, color }: { label: string; value: string; color: string }) {
  return <div className="rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200"><p className="text-sm text-slate-500">{label}</p><h2 className={`mt-3 text-3xl font-bold ${color}`}>{value}</h2></div>;
}
function EmptyState({ text }: { text: string }) {
  return <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 px-4 py-10 text-center"><p className="font-medium text-slate-700">{text}</p></div>;
}
function SectionHeader({ title, subtitle, onClick }: { title: string; subtitle: string; onClick: () => void }) {
  return <div className="mb-4 flex items-center justify-between gap-3"><div><h2 className="text-xl font-semibold">{title}</h2><p className="text-sm text-slate-500">{subtitle}</p></div><button onClick={onClick} className="hidden rounded-2xl bg-slate-900 px-4 py-2 font-medium text-white transition hover:bg-slate-800 md:block">Novo</button></div>;
}
function Field({ label, children, className = "" }: { label: string; children: React.ReactNode; className?: string }) {
  return <div className={className}><label className="mb-1 block text-sm font-medium text-slate-700">{label}</label>{children}</div>;
}
function Modal({ title, subtitle, onClose, children }: { title: string; subtitle: string; onClose: () => void; children: React.ReactNode }) {
  return <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"><div className="w-full max-w-2xl rounded-3xl bg-white p-5 shadow-2xl"><div className="mb-5 flex items-center justify-between gap-3"><div><h2 className="text-2xl font-bold text-slate-900">{title}</h2><p className="text-sm text-slate-500">{subtitle}</p></div><button onClick={onClose} className="rounded-xl bg-slate-100 px-3 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-200">Fechar</button></div>{children}</div></div>;
}
